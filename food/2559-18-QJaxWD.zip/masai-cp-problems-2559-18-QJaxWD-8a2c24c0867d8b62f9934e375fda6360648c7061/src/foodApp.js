const getCategoriesData = async () => {
  // code here
};

const getIngredientData = async () => {
  // code here
};

window.onload = function () {
  //  get the buttons here and add click event
};

// donot chnage the export statement

if (typeof exports !== "undefined") {
  module.exports = {
    getCategoriesData,
    getIngredientData,
  };
}
